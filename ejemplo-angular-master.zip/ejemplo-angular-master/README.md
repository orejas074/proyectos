# ejemplo-angular
Ejemplo básico de angular js para exposición seminario
