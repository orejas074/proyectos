public class OperacionesMatematicas {
    double num1;
    double num2;
    public OperacionesMatematicas(double num1,double num2){
        this.num1=num1;
        this.num2=num2;
    }
    public double Sumar(){
        double sum;
        sum=num1+num2;
        return sum;
    }
    public double Restar(){
        return num1-num2;
    }
    public double Multiplicar(){
        return num1*num2;
    }
    public double dividir(){
    if (num2!=0)
    {
	return num1/num2;
    }
        return Double.MAX_VALUE;
    }
            
}
